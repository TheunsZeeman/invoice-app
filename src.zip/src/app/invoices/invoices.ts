export interface Invoices {
    id: number;
    name: string;
    description: string;
    quantity: number;
    price: number;
}
export interface Items {
    id: number;
    description: string;
    quantity: number;
    price: number;
}